"""webdoc URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from docbase.views import index_home,index2,indexfilter,index_register,index_two,index_sortcost,index_sortexp
from rest_framework.urlpatterns import format_suffix_patterns
from docbase import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('allusers/',views.UserList.as_view()),
    path('',index_home,name="homepage"),
    path('register/',index_register,name="regi"),
    path('register/doctors/',index_two),
    path('doctors/',index2),
    path('doctors/filterdoc/sortedcost/',index_sortcost,name="sortedcost"),
    path('doctors/filterdoc/sortedexp/',index_sortexp,name="sortedexp"),
    path('doctors/filterdoc/',indexfilter),
    path('register/doctors/filterdoc/',indexfilter)
]
