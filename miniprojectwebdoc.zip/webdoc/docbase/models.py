from django.db import models

# Create your models here.

class Doctor(models.Model) :
    name_of_doctor = models.CharField(max_length=100)
    fee = models.FloatField()
    gender = models.CharField(max_length=8)
    years_of_experience = models.IntegerField()
    college = models.CharField(max_length=50)
    clinic = models.CharField(max_length=50)
    address = models.CharField(max_length=150,default='NA')
    type = models.CharField(max_length=30)
    availability = models.BooleanField()
    url = models.CharField(max_length=100, default="male1.jpg")



class User(models.Model):
    full_name = models.CharField(max_length=100)
    username = models.CharField(max_length=14)
    password = models.CharField(max_length=20)
    email_id = models.CharField(max_length=40)
    contact = models.IntegerField()
    type_of_user =models.CharField(max_length=10)