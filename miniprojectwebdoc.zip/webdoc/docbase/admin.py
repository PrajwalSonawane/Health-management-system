from django.contrib import admin
from .models import Doctor,User

class DoctorAdmin(admin.ModelAdmin):
    list_display=('name_of_doctor','gender','years_of_experience','clinic','type'
                 ,'availability')

class UserAdmin(admin.ModelAdmin):
    list_display=('full_name','username','email_id','contact','type_of_user')


admin.site.register(Doctor,DoctorAdmin)
admin.site.register(User,UserAdmin)

