from .views import index_home,index2
from django.urls import path


urlpatterns = [

]