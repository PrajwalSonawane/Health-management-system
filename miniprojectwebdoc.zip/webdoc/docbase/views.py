from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from .models import Doctor
from .models import User
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import JSONParser
from .serializers import UserSerializer
#from .serializers import DoctorSerializer


class UserList(APIView):

    def get(self,request):
        allusers = User.objects.all()
        serializer = UserSerializer(allusers,many=True)
        print("following is :")
        print(serializer.data)
        return Response(serializer.data)

    def post(self,request):
        data = JSONParser().parse(request)
        username_android = data["username"]
        password_android = data["password"]

        allmyuserlist = User.objects.all()
        for x in allmyuserlist :
            if x.username == username_android and x.password == password_android :
                return Response(status=200)

        return Response(status=401)


def index_two(request):
    '''if ('fullname' not in request.GET.keys()) or('username' not in request.GET.keys()) or('password' not in request.GET.keys()) or('email' not in request.GET.keys()) or('contact' not in request.GET.keys()) or('typeuser' not in request.GET.keys()) or('accepted' not in request.GET.keys()) :
        return render(request,'register.html',{'depend': 'incompletefield'})
    name = request.GET["fullname"]
    usernme = request.GET["username"]
    password = request.GET["password"]
    email = request.GET["email"]
    contact = request.GET["contact"]
    typeuser = request.GET["typeuser"]
    '''
    alldoc = User.objects.all()

    for x in alldoc :
        if x.username == request.GET["username"] :
            return render(request,'register.html',{'depend': 'alreadyuser'})


    new_user = User()
    new_user.full_name = request.GET["fullname"]
    new_user.username = request.GET["username"]
    new_user.password = request.GET["password"]
    new_user.email_id = request.GET["email"]
    new_user.contact = int(request.GET["contact"])
    new_user.type_of_user = request.GET["typeuser"]
    new_user.save()

    return render(request,'filter.html',{'check':'newuserdone'})


def index_home(request):
    return render(request,'homepage.html')


def index_sortcost(request):
    alldoc_sorted = Doctor.objects.all().order_by('fee')

    return render(request,'displaydoc.html',{'alldoc':alldoc_sorted})

def index_sortexp(request):
    alldoc_sorted = Doctor.objects.all().order_by('-years_of_experience')

    return render(request,'displaydoc.html',{'alldoc':alldoc_sorted})


def index_register(request):
    return render(request,'register.html',{'depend':'initial'})


def index2(request):
    usr = request.GET["username"]
    pas = request.GET["password"]
    alldoc = User.objects.all()

    for x in alldoc:
        if x.username == request.GET["username"] and x.password == request.GET["password"]:
            return render(request, 'filter.html', {'check': 'normal'})

    return render(request, 'homepage.html', {'depend': 'invalid'})


def indexfilter(request):
    alldoc = Doctor.objects.all()
    str1,str2 = 'off','off'
    if 'male' in request.GET.keys() :
        str1 = request.GET["male"]
    if 'female' in request.GET.keys():
        str2 = request.GET["female"]
    if str1 == 'on':
        str1 = 'M'
    if str2 == 'on':
        str2 = 'F'
    L=[]
    for x in alldoc :
        if x.gender == str1 or x.gender == str2 :
            L.append(x)



    t1,t2,t3,t4 = 'off','off','off','off'
    if 'exp1' in request.GET.keys() :
        t1 = request.GET["exp1"]
    if 'exp2' in request.GET.keys():
        t2 = request.GET["exp2"]
    if 'exp3' in request.GET.keys():
        t3 = request.GET["exp3"]
    if 'exp4' in request.GET.keys():
        t4 = request.GET["exp4"]

    choice = 0
    if t1 == 'on':
        choice = 1
    elif t2 == 'on':
        choice = 2
    elif t3 == 'on':
        choice = 3
    elif t4 == 'on':
        choice = 4

    for x in alldoc :
        if x in L :
            if x.years_of_experience <=5 and choice<=0 :
                pass
            elif x.years_of_experience <= 10 and x.years_of_experience > 5 and choice<=1 :
                pass
            elif x.years_of_experience <= 20 and x.years_of_experience > 10 and choice<=2 :
                pass
            elif x.years_of_experience <= 30 and x.years_of_experience > 20 and choice<=3 :
                pass
            elif x.years_of_experience >30 and choice<=4 :
                pass
            else :
                L.remove(x)

    print(L)
    t1, t2, t3 = 'off', 'off', 'off'
    if 'cost1' in request.GET.keys():
        t1 = request.GET["cost1"]
    if 'cost2' in request.GET.keys():
        t2 = request.GET["cost2"]
    if 'cost3' in request.GET.keys():
        t3 = request.GET["cost3"]

    choice = 4
    if t3 == 'on':
        choice = 3
    elif t2 == 'on':
        choice = 2
    elif t1 == 'on':
        choice = 1

    for x in alldoc :
        if x in L:
            if choice == 4:
                pass
            elif choice == 3 and x.fee <1000 :
                pass
            elif choice == 2 and x.fee <500 :
                pass
            elif choice == 1 and x.fee <100 :
                pass
            else :
                L.remove(x)

    D=[]
    for x in L :
        if x in L:
            if ('gen' in request.GET.keys() ) :
                if x.type == 'General Physician':
                    D.append(x)
            if ('sur' in request.GET.keys() ) :
                if x.type == 'Surgeon':
                    D.append(x)
            if ('oph' in request.GET.keys() ) :
                if x.type == 'Ophthalmologist':
                    D.append(x)
            if ('car' in request.GET.keys() ) :
                if x.type == 'Cardiologist':
                    D.append(x)
            if ('all' in request.GET.keys() ) :
                if x.type == 'Allergist':
                     D.append(x)
            if ('neu' in request.GET.keys() ) :
                if x.type == 'Neurologist':
                    D.append(x)
            if ('rad' in request.GET.keys() ) :
                if x.type == 'Radiologist':
                    D.append(x)
            if ('der' in request.GET.keys() ) :
                if x.type == 'Dermatologist':
                     D.append(x)
            if ('den' in request.GET.keys() ) :
                if x.type == 'Dentist':
                    D.append(x)


    return render(request,'displaydoc.html',{'alldoc':D})
