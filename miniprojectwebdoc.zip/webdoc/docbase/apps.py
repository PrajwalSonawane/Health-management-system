from django.apps import AppConfig


class DocbaseConfig(AppConfig):
    name = 'docbase'
